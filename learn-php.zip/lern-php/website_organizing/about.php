<?php include 'includes/header.php'; ?>


<h1>About Page</h1>

<?php include 'includes/footer.php'; ?>