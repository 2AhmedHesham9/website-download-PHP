<?php include 'includes/header.php' ?>
<h1>
    hi Contact
</h1>
<?php include 'includes/footer.php' ?>