<footer>
        <p>copyrights &copy; 2023</p>
    </footer>
    
</body>
</html>