<?php include 'includes/header.php'; ?>

<h1 id="#home">Home Page</h1>

<?php include 'includes/footer.php'; ?>