
--   run this code in xampp

create DATABASE images

create table image(
id int PRIMARY KEY AUTO_INCREMENT,
    `filename` varchar(100) not null
    

);