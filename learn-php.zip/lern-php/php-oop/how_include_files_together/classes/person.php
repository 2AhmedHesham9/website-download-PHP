<?php


// namespace home;
// include  '../includes/autoloader.php';

class person
{

    function move()
    {
        echo ("move ya Atsh mn class el person☺");
    }
}
