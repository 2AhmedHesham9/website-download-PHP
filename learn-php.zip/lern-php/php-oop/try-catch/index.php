
<?php



class ahmed
{
  private $name;

  public function setname(string $n)
  {
    $this->name = $n;
  }
  public function getname()
  {
    return  $this->name;
  }
}




?>