<!-- 
    $_REQUEST //DO $_POST or _$_GET
 -->



<!-- 
    $_GET
 -->

<?php

// if (isset($_GET['word']) && (!empty($_GET['word']))) {
//     $word = $_GET['word'];
//     var_dump($word);
// } else {
//     echo "Please, enter words....";
// }

?>

<!-- 
    $_POST
-->
<?php

// if (isset($_POST['word']) && (!empty($_POST['word']))) {
//     $word = $_POST['word'];
//     var_dump(($word));
// } else {
//     echo "Please, enter word Post....";
// }

?>