<?php


// foreach loop

$names = ['a', 'b', 'c'];
foreach ($names as $name)     //$names=>array .... $name=>variable carry values as a,b,c
{
    // echo $name . '<br>';

}

// For loop

for ($i = 0; $i < count($names); $i++)  //function count()to get the length of array
{
    // echo $names[$i] .' ';
}


// while loop
$x = 0;
while ($x <= 10) {
    // echo $x .' ';
    // $x++;
}
