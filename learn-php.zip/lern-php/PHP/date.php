<?php
//day

// echo date('d'); //get day as 2 digit
// echo date('D'); //get name of day
// echo date('j'); //get day without 0 if day from 1 to 9

//month

// echo date('F'); //get name of month
// echo date('M'); //get abbreviation  name of month
// echo date('m'); //get number of month

//year

// echo date('Y'); //get the year as 2023 
// echo date('y'); //get the year as 23 

//full date
// echo date('d') . " / ". date('m') . " / ". date('Y');
// echo date('d / F / y');

                //time
                // date_default_timezone_set('Africa/Cairo');              
                  // echo Date('h'); //get hour
                //   echo Date('i '); //get minuits
                //   echo Date('s'); //get seconds
                // echo Date('h:i:s a'); //get hour with (a)-> pm or am

              //  echo date('H:i:s'); //24 hour system


?>