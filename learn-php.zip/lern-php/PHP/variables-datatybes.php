<?php



/*  Variables naming in php:

- start with $
- cant start with number
- alph numeric
- can start with _
- case sensitive  ... $age != $AGE

*/




/* data types in php:*/

// string 
// $name="ahmed";

// integer float double
// $age=20;

// (.) in echo means concatinate as (+)in c++ or js;

// echo $name . " " .$age;

// echo "$name $age"; in "" you can print variables but in single '' you cant;

// boolean True or false



// typs of printing //
// $name="ATSH";  
// echo $name;
// var_dump($name); //print datatype of variable and value .. if datatype is string print length pf string too;
// unset($name); //make  variable Undefined ;
// echo $name;
