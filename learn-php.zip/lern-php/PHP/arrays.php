<?php
    

    // $names=['a','b','c'];
    $names =array('a','b','c');
    $names[]='d';  //adding 
   

                            // Override array //
                            //Assosative array //
//   $names = [
//     '0'=>'ahmed',
//     '1'=>'ahmed',
//     '2'=>'ahmed',
//     '3'=>'ahmed'
//   ];

    
    
    
//var_dump($names);
// print_r($names);

                                   //  way to make two dimintial array
    
                    // $students = [
                    //     [
                    //         'name' =>"ahmed",
                    //         'grade' =>3.7,
                        
                    //     ],
                    //     [
                    //         'name' =>"mo",
                    //         'grade' =>3.7,
                    
                            
                    //     ],
                    //     [
                    //         'name' =>"zzz",
                    //         'grade' =>2.7,
                        
                    //     ],
                    //     ];

                    // echo $students[0]['grade];  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    // var_dump($students);
                    // echo '<pre>';
                
                    // print_r($students);
                    // echo '</pre>';



                
                                //way to make three dimintial array

            // $students = [
            // [
            //     'name' =>"ahmed",
            //     'grade' =>3.7,
            //     'dept'=>[
            //         'it','markiting'
            //     ]
            // ],
            // [
            //     'name' =>"mo",
            //     'grade' =>3.7,
            //     'dept'=>[
            //         'Finance','sales'
            //     ]
                
            // ],
            // [
            //     'name' =>"zzz",
            //     'grade' =>2.7,
            //     'dept'=>[
            //         'HR','markiting'
            //     ]
            // ],
            // ];
    
            //     // echo $students[0]['dept'][1];
            //     echo '<pre>';
            //     print_r($students);
            //     echo '</pre>';





    
    
    
    ?>

                            