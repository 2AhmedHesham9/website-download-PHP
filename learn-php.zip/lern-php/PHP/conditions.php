<?php
 
    //if statements

    // $bool =true;
    // if($bool)
    // {
    //     // echo "true";
    // }
    // else
    // {
    //     // echo "false";
    // }
    
    
    
            // logical operator
            //   ==  != && ||
            
            // $temp=21;
            // if($temp<22)echo " cool day ";
            // elseif($temp>20 && $temp<30)echo " nice day";
            // else echo"hot day";
            
            
            // echo $bool ?  'true ':'false';
            

                                           // switch case

                        // $color="yellow";
                        // switch($color)
                        // {
                        //     case 'red':
                        //         echo 'red';
                        //         break;
                        //     case 'yellow':
                        //         echo 'Suiiiiiiiiiiiiiiiiiiiiiiiiii';
                        //         break;
                        //     default :
                        //     echo "NO color";        
                        // }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
 
 ?>