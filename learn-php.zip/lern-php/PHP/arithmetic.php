<?php


//addition
$n=0;
$n++;
$n*=5;
// echo $n;

//subtraction
$n1=100;
$n2=300;
// echo $n2 - $n1;

//percentage + formamating

$n3=500;
$n4=407;
$percent=($n4 /$n3)*100;
$percent=number_format($percent,5);
// echo $percent;


//reminder

$n5=20;
$n6=3;
$rem=$n5 % $n6;
// echo $rem;


//power
$n7=7;
echo $n7 ** 2;
