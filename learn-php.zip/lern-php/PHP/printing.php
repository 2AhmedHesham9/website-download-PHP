<?php
// echo
        //  echo 'Ahmed ','Hesham ','Atsh';// you can use (,) between outputs
        //  echo 'Ahmed '.'Hesham '.'Atsh';// you can use (.) between outputs as concatinate

        // echo does not return boolean value if(echo('')){}
                // if(echo 'Ahmed ')
                // {
                //     echo 'Hesham';
                // }


// print
        // print 'Ahmed ','Hesham ','Atsh';// you can NOT use (,) between outputs
        // print 'Ahmed '.'Hesham '.'Atsh';// you can  use (.) between outputs
                if(print 'Ahmed ') //returns boolean value
                // {
                //     print ('Hesham' . ' ATSH');
                //     print ('Hesham' , ' Atsh'); // does not work
                // }

// printf()
        $day=6;
        // printf('This is %dth of the week',$day); //%d book a place for variable
        // echo '<br>';
        // printf('your balance is %.3f',10.123123); //%f book a place for variable ( .3 ) get 3  digits after (.)
        // echo '<br>';
        // printf('the hex decimal for %d = %x',214,214); //%d book a place for variable (%x) variable to convert to hexdicimal
        
        
        
        // print_r() ''  var_dump
        
        // $pepole =[
                
        //         [
        //                 'name'=> 'Ahmed ',
        //                 'age'=>20
        //         ],
        //         [
        //                 'name'=> 'Mohamed ',
        //                 'age'=>24
        //         ],
        //         [
        //                 'name'=> 'ATSH ',
        //                 ' age'=>24
        //                 ]
        //         ];
                
        //         print_r($pepole); //print array normaly
        //         echo '<br>';
        //         var_dump($pepole );  //print array with length and datatype of any variable  
                

        //         echo'<pre>';
        //         var_dump($pepole); 
        //         echo '</pre>';











?>